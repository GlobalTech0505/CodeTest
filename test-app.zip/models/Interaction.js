const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const InteractionSchema = new Schema({
  user1Id: { type: Schema.Types.ObjectId, ref: 'User' },
  user2Id: { type: Schema.Types.ObjectId, ref: 'User' },
  interactionType: { type: String, enum: ['like', 'superlike', 'dislike'] }
});

module.exports = mongoose.model('Interaction', InteractionSchema);
