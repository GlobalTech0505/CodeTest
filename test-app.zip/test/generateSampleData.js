const mongoose = require('mongoose');
const faker = require('faker');
const User = require('../models/User');
const Interaction = require('../models/Interaction');
const Block = require('../models/Block');
const databaseConfig = require('../config/database');

// Connect to MongoDB
mongoose.connect(databaseConfig.url, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Function to generate random users
async function generateUsers(numUsers) {
  const users = [];
  
  for (let i = 0; i < numUsers; i++) {
    const user = new User({
      name: faker.name.findName(),
      age: faker.datatype.number({ min: 18, max: 60 }),
      gender: faker.random.arrayElement(['male', 'female', 'other']),
      location: {
        type: 'Point',
        coordinates: [
          faker.address.longitude(),
          faker.address.latitude(),
        ],
      },
    });

    users.push(user);
  }

  await User.insertMany(users);
  console.log(`${numUsers} users generated`);
}

// Function to generate random interactions
// Function to generate random interactions
async function generateInteractions(numInteractions, userIds) {
    const batchSize = 10000;
    
    for (let i = 0; i < numInteractions; i += batchSize) {
      const interactions = [];
      for (let j = 0; j < batchSize; j++) {
        const user1Id = faker.random.arrayElement(userIds);
        let user2Id = faker.random.arrayElement(userIds);
        
        while (user1Id.toString() === user2Id.toString()) {
          user2Id = faker.random.arrayElement(userIds);
        }
  
        const interaction = new Interaction({
          user1Id,
          user2Id,
          interactionType: faker.random.arrayElement(['like', 'superlike', 'dislike']),
        });
  
        interactions.push(interaction);
      }
      await Interaction.insertMany(interactions);
      console.log(`${Math.min(i + batchSize, numInteractions)} interactions generated`);
    }
  }
  
  // Function to generate random blocks
  async function generateBlocks(numBlocks, userIds) {
    const batchSize = 10000;
    
    for (let i = 0; i < numBlocks; i += batchSize) {
      const blocks = [];
      for (let j = 0; j < batchSize; j++) {
        const user1Id = faker.random.arrayElement(userIds);
        let user2Id = faker.random.arrayElement(userIds);
        
        while (user1Id.toString() === user2Id.toString()) {
          user2Id = faker.random.arrayElement(userIds);
        }
  
        const block = new Block({
          user1Id,
          user2Id,
        });
  
        blocks.push(block);
      }
      await Block.insertMany(blocks);
      console.log(`${Math.min(i + batchSize, numBlocks)} blocks generated`);
    }
  }

// Main function to generate data
async function generateSampleData() {
  await mongoose.connection.dropDatabase();

  const numUsers = 30000;
  const numInteractions = 3000000;
  const numBlocks = 100000;

  await generateUsers(numUsers);

  const users = await User.find({});
  const userIds = users.map(user => user._id);
  console.log("load success");

  await generateInteractions(numInteractions, userIds);
  console.log("load success1");
  await generateBlocks(numBlocks, userIds);
  console.log("load success2");

  mongoose.connection.close();
}

generateSampleData().catch(err => {
  console.error(err);
  mongoose.connection.close();
});
