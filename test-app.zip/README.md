# Tinder-Like Application

## Project Overview

This project is a simplified version of a Tinder-like application using Node.js and MongoDB. The main focus is on designing the database structure and implementing a specific query to retrieve a paginated list of users for interactions.

## Database Schema

- **Users Collection:** Stores user information including age, gender, and location.
- **Interactions Collection:** Stores interactions between users such as likes, superlikes, and dislikes.
- **Blocks Collection:** Stores information about which users have blocked each other.

## Query Implementation

The `getPaginatedUsers` function retrieves a paginated list of users based on the following criteria:
1. Filters users by preferred age range, gender, and distance from the current user.
2. Excludes users that the current user has already interacted with.
3. Excludes users that the current user has blocked or who have blocked the current user.
4. Sorts the list such that users who have superliked the current user appear first.
5. Implements pagination with a default of 20 users per page.

## Performance Considerations

The implementation is optimized to handle:
- Approximately 30,000 overall users.
- About 3 million interactions between users.
- Support for around 10,000 simultaneous active users, with each user making a request every 2 seconds.

This solution leverages MongoDB's aggregation framework to efficiently filter, sort, and paginate the user list, ensuring scalability and performance.

## How to Run

1. Ensure MongoDB is installed and running.
2. Run `npm install` to install dependencies.
3. Update the MongoDB connection string if necessary.
4. Execute the script with `node app.js`.

## Performance Metrics

Due to the constraints of this submission, detailed performance metrics and stress test results are not included. However, the design and indexing strategies are aimed to handle high loads and ensure efficient querying.

## Assumptions

- The user's location is stored as a GeoJSON Point.
- Distance calculations are based on a spherical model.
- The `maxDistance` parameter in the `geoNear` query is set to 50 km, which can be adjusted based on requirements.
