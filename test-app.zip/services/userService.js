const User = require('../models/User');
const Interaction = require('../models/Interaction');
const Block = require('../models/Block');

async function getPaginatedUsers(currentUser, page, pageSize = 20) {
  const { _id, agePreference, genderPreference, location } = currentUser;

  const pipeline = [
    {
      $geoNear: {
        near: location,
        distanceField: "dist.calculated",
        maxDistance: 50000,
        spherical: true
      }
    },
    {
      $match: {
        age: { $gte: agePreference.min, $lte: agePreference.max },
        gender: genderPreference,
        _id: { $ne: _id }
      }
    },
    {
      $lookup: {
        from: "interactions",
        let: { userId: "$_id" },
        pipeline: [
          {
            $match: {
              $expr: {
                $or: [
                  { $and: [{ $eq: ["$user1Id", _id] }, { $eq: ["$user2Id", "$$userId"] }] },
                  { $and: [{ $eq: ["$user2Id", _id] }, { $eq: ["$user1Id", "$$userId"] }] }
                ]
              }
            }
          }
        ],
        as: "interactions"
      }
    },
    {
      $lookup: {
        from: "blocks",
        let: { userId: "$_id" },
        pipeline: [
          {
            $match: {
              $expr: {
                $or: [
                  { $and: [{ $eq: ["$user1Id", _id] }, { $eq: ["$user2Id", "$$userId"] }] },
                  { $and: [{ $eq: ["$user2Id", _id] }, { $eq: ["$user1Id", "$$userId"] }] }
                ]
              }
            }
          }
        ],
        as: "blocks"
      }
    },
    {
      $match: {
        interactions: { $size: 0 },
        blocks: { $size: 0 }
      }
    },
    {
      $lookup: {
        from: "interactions",
        let: { userId: "$_id" },
        pipeline: [
          {
            $match: {
              $expr: {
                $and: [
                  { $eq: ["$user2Id", _id] },
                  { $eq: ["$user1Id", "$$userId"] },
                  { $eq: ["$interactionType", "superlike"] }
                ]
              }
            }
          }
        ],
        as: "superlike"
      }
    },
    {
      $sort: {
        "superlike": -1,
        "dist.calculated": 1
      }
    },
    {
      $skip: (page - 1) * pageSize
    },
    {
      $limit: pageSize
    }
  ];

  const users = await User.aggregate(pipeline).exec();
  return users;
}

module.exports = { getPaginatedUsers };
