const userService = require('../services/userService');

exports.getPaginatedUsers = async (req, res) => {
  
  console.log('POST /paginated', req.body);
  try {
    const { currentUser, page } = req.body;
    const users = await userService.getPaginatedUsers(currentUser, page);
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};